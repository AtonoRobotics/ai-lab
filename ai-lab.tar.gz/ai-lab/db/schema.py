"""
db/schema.py — PhysicsDB
Single access point for all fleet physics data.
Never call sqlite3.connect() directly — always use this class.
"""
import sqlite3, json
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

SCHEMA_VERSION = "1.0.0"

DDL = """
CREATE TABLE IF NOT EXISTS schema_meta (
    key TEXT PRIMARY KEY, value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS robots (
    robot_id            TEXT PRIMARY KEY,
    name                TEXT NOT NULL,
    arm_manufacturer    TEXT,
    arm_model           TEXT,
    arm_model_confirmed INTEGER DEFAULT 0,
    controller          TEXT,
    axes_count          INTEGER,
    payload_kg          REAL,
    reach_mm            REAL,
    repeatability_mm    REAL,
    urdf_path           TEXT,
    usd_path            TEXT,
    source_url          TEXT,
    source_doc          TEXT,
    notes               TEXT,
    updated_at          TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS joints (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    robot_id        TEXT NOT NULL REFERENCES robots(robot_id),
    joint_index     INTEGER NOT NULL,
    joint_name      TEXT,
    joint_type      TEXT NOT NULL DEFAULT 'revolute',
    dh_a_m          REAL,
    dh_d_m          REAL,
    dh_alpha_rad    REAL,
    dh_theta_offset REAL DEFAULT 0.0,
    lower_limit     REAL,
    upper_limit     REAL,
    velocity_limit  REAL,
    effort_nm       REAL,
    physx_kp        REAL,
    physx_kd        REAL,
    physx_friction  REAL,
    verified        INTEGER DEFAULT 0,
    gate_id         TEXT,
    source_doc      TEXT,
    notes           TEXT,
    updated_at      TEXT NOT NULL,
    UNIQUE(robot_id, joint_index)
);
CREATE TABLE IF NOT EXISTS links (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    robot_id    TEXT NOT NULL REFERENCES robots(robot_id),
    link_index  INTEGER NOT NULL,
    link_name   TEXT NOT NULL,
    mass_kg     REAL,
    com_x       REAL, com_y REAL, com_z REAL,
    ixx REAL, iyy REAL, izz REAL,
    ixy REAL DEFAULT 0, ixz REAL DEFAULT 0, iyz REAL DEFAULT 0,
    visual_mesh     TEXT,
    collision_mesh  TEXT,
    verified        INTEGER DEFAULT 0,
    gate_id         TEXT,
    source_doc      TEXT,
    updated_at      TEXT NOT NULL,
    UNIQUE(robot_id, link_index)
);
CREATE TABLE IF NOT EXISTS cameras (
    camera_id   TEXT PRIMARY KEY,
    manufacturer TEXT NOT NULL,
    model       TEXT NOT NULL,
    mount       TEXT,
    body_mass_kg REAL,
    sensor_format TEXT,
    source_url  TEXT,
    notes       TEXT,
    updated_at  TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS lenses (
    lens_id         TEXT PRIMARY KEY,
    manufacturer    TEXT NOT NULL,
    family          TEXT,
    focal_length_mm REAL,
    mount           TEXT NOT NULL,
    t_stop_min      REAL,
    mass_kg         REAL,
    fiz_compatible  INTEGER DEFAULT 1,
    source_url      TEXT,
    notes           TEXT,
    updated_at      TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS gate_approvals (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    gate_id     TEXT NOT NULL,
    robot_id    TEXT NOT NULL,
    approved_at TEXT NOT NULL,
    approved_by TEXT NOT NULL,
    notes       TEXT
);
CREATE TABLE IF NOT EXISTS architecture_decisions (
    decision_id TEXT PRIMARY KEY,
    title       TEXT NOT NULL,
    status      TEXT NOT NULL DEFAULT 'ACCEPTED',
    decision    TEXT NOT NULL,
    rationale   TEXT,
    decided_at  TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS audit_log (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    ts          TEXT NOT NULL,
    agent       TEXT NOT NULL,
    op          TEXT NOT NULL,
    table_name  TEXT NOT NULL,
    row_id      TEXT NOT NULL,
    source      TEXT
);
"""


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class PhysicsDB:
    def __init__(self, path: str = "db/fleet.db"):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self.path))
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA foreign_keys = ON")
        self._conn.execute("PRAGMA journal_mode = WAL")
        self._conn.executescript(DDL)
        self._conn.execute(
            "INSERT OR REPLACE INTO schema_meta VALUES ('version', ?)",
            (SCHEMA_VERSION,)
        )
        self._conn.commit()

    # ── Internal ──────────────────────────────────────────────────────────────
    def _audit(self, agent: str, op: str, table: str, row_id: str, source: str = None):
        self._conn.execute(
            "INSERT INTO audit_log(ts,agent,op,table_name,row_id,source) VALUES(?,?,?,?,?,?)",
            (_now(), agent, op, table, row_id, source)
        )

    def _require_source(self, data: dict, label: str):
        if not data.get("source_url") and not data.get("source_doc"):
            raise ValueError(f"source_url or source_doc required for {label}")

    # ── Robots ────────────────────────────────────────────────────────────────
    def upsert_robot(self, agent: str, data: dict):
        self._require_source(data, f"robot {data.get('robot_id')}")
        data["updated_at"] = _now()
        cols = list(data.keys())
        placeholders = ",".join("?" * len(cols))
        updates = ",".join(f"{c}=excluded.{c}" for c in cols if c != "robot_id")
        self._conn.execute(
            f"INSERT INTO robots({','.join(cols)}) VALUES({placeholders}) "
            f"ON CONFLICT(robot_id) DO UPDATE SET {updates}",
            [data[c] for c in cols]
        )
        self._audit(agent, "UPSERT", "robots", data["robot_id"], data.get("source_url"))
        self._conn.commit()

    def get_robot(self, robot_id: str) -> Optional[sqlite3.Row]:
        return self._conn.execute(
            "SELECT * FROM robots WHERE robot_id=?", (robot_id,)
        ).fetchone()

    def all_robots(self):
        return self._conn.execute("SELECT * FROM robots ORDER BY robot_id").fetchall()

    # ── Joints ────────────────────────────────────────────────────────────────
    def upsert_joint(self, agent: str, robot_id: str, idx: int, data: dict, source: str):
        if not source:
            raise ValueError(f"source required for {robot_id} J{idx}")
        data.update({"robot_id": robot_id, "joint_index": idx,
                     "source_doc": source, "updated_at": _now()})
        cols = list(data.keys())
        placeholders = ",".join("?" * len(cols))
        updates = ",".join(
            f"{c}=excluded.{c}" for c in cols
            if c not in ("robot_id", "joint_index")
        )
        self._conn.execute(
            f"INSERT INTO joints({','.join(cols)}) VALUES({placeholders}) "
            f"ON CONFLICT(robot_id,joint_index) DO UPDATE SET {updates}",
            [data[c] for c in cols]
        )
        self._audit(agent, "UPSERT", "joints", f"{robot_id}:J{idx}", source)
        self._conn.commit()

    def get_joints(self, robot_id: str, verified_only=False):
        q = "SELECT * FROM joints WHERE robot_id=?"
        if verified_only:
            q += " AND verified=1"
        return self._conn.execute(q + " ORDER BY joint_index", (robot_id,)).fetchall()

    def approve_joints(self, robot_id: str, gate_id: str, approved_by: str, notes=""):
        self._conn.execute(
            "UPDATE joints SET verified=1, gate_id=?, updated_at=? WHERE robot_id=?",
            (gate_id, _now(), robot_id)
        )
        self._conn.execute(
            "INSERT INTO gate_approvals(gate_id,robot_id,approved_at,approved_by,notes) "
            "VALUES(?,?,?,?,?)",
            (gate_id, robot_id, _now(), approved_by, notes)
        )
        self._conn.commit()

    # ── Links ─────────────────────────────────────────────────────────────────
    def upsert_link(self, agent: str, robot_id: str, idx: int, data: dict, source: str):
        if not source:
            raise ValueError(f"source required for {robot_id} L{idx}")
        data.update({"robot_id": robot_id, "link_index": idx,
                     "source_doc": source, "updated_at": _now()})
        cols = list(data.keys())
        placeholders = ",".join("?" * len(cols))
        updates = ",".join(
            f"{c}=excluded.{c}" for c in cols
            if c not in ("robot_id", "link_index")
        )
        self._conn.execute(
            f"INSERT INTO links({','.join(cols)}) VALUES({placeholders}) "
            f"ON CONFLICT(robot_id,link_index) DO UPDATE SET {updates}",
            [data[c] for c in cols]
        )
        self._audit(agent, "UPSERT", "links", f"{robot_id}:L{idx}", source)
        self._conn.commit()

    def get_links(self, robot_id: str, verified_only=False):
        q = "SELECT * FROM links WHERE robot_id=?"
        if verified_only:
            q += " AND verified=1"
        return self._conn.execute(q + " ORDER BY link_index", (robot_id,)).fetchall()

    def approve_links(self, robot_id: str, gate_id: str, approved_by: str, notes=""):
        self._conn.execute(
            "UPDATE links SET verified=1, gate_id=?, updated_at=? WHERE robot_id=?",
            (gate_id, _now(), robot_id)
        )
        self._conn.commit()

    # ── Cameras / Lenses ──────────────────────────────────────────────────────
    def upsert_camera(self, agent: str, data: dict):
        data["updated_at"] = _now()
        cols = list(data.keys())
        self._conn.execute(
            f"INSERT OR REPLACE INTO cameras({','.join(cols)}) "
            f"VALUES({','.join('?'*len(cols))})",
            [data[c] for c in cols]
        )
        self._conn.commit()

    def upsert_lens(self, agent: str, data: dict):
        data["updated_at"] = _now()
        cols = list(data.keys())
        self._conn.execute(
            f"INSERT OR REPLACE INTO lenses({','.join(cols)}) "
            f"VALUES({','.join('?'*len(cols))})",
            [data[c] for c in cols]
        )
        self._conn.commit()

    def all_lenses(self):
        return self._conn.execute("SELECT * FROM lenses ORDER BY lens_id").fetchall()

    # ── ADRs ──────────────────────────────────────────────────────────────────
    def record_decision(self, did: str, title: str, decision: str, rationale: str):
        self._conn.execute(
            "INSERT OR REPLACE INTO architecture_decisions"
            "(decision_id,title,decision,rationale,decided_at) VALUES(?,?,?,?,?)",
            (did, title, decision, rationale, _now())
        )
        self._conn.commit()

    def all_decisions(self):
        return self._conn.execute(
            "SELECT * FROM architecture_decisions ORDER BY decision_id"
        ).fetchall()

    # ── Gate approvals ────────────────────────────────────────────────────────
    def gate_approved(self, gate_id: str, robot_id: str = None) -> bool:
        q = "SELECT id FROM gate_approvals WHERE gate_id=?"
        params = [gate_id]
        if robot_id:
            q += " AND robot_id=?"
            params.append(robot_id)
        return self._conn.execute(q, params).fetchone() is not None

    # ── Export for URDF agent ──────────────────────────────────────────────────
    def export_for_urdf(self, robot_id: str) -> dict:
        robot = self.get_robot(robot_id)
        if not robot:
            raise ValueError(f"Robot {robot_id} not found")
        joints = self.get_joints(robot_id, verified_only=True) or self.get_joints(robot_id)
        links  = self.get_links(robot_id,  verified_only=True) or self.get_links(robot_id)
        return {
            "robot":        dict(robot),
            "joints":       [dict(j) for j in joints],
            "links":        [dict(l) for l in links],
            "all_verified": all(j["verified"] for j in joints),
        }

    def close(self):
        self._conn.close()
