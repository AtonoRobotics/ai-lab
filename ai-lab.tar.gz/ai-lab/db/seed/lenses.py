"""db/seed/lenses.py — Cinema lens seed data."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from db.schema import PhysicsDB


def seed(db: PhysicsDB):
    lenses = [
        # ARRI Signature Primes (LPL)
        {"lens_id": "ARRI_SIG_18",  "manufacturer": "ARRI", "family": "Signature Prime",
         "focal_length_mm": 18,  "mount": "LPL", "t_stop_min": 1.8, "mass_kg": 1.50,
         "source_url": "https://www.arri.com/en/camera-systems/lenses/arri-signature-primes"},
        {"lens_id": "ARRI_SIG_25",  "manufacturer": "ARRI", "family": "Signature Prime",
         "focal_length_mm": 25,  "mount": "LPL", "t_stop_min": 1.8, "mass_kg": 1.49,
         "source_url": "https://www.arri.com/en/camera-systems/lenses/arri-signature-primes"},
        {"lens_id": "ARRI_SIG_35",  "manufacturer": "ARRI", "family": "Signature Prime",
         "focal_length_mm": 35,  "mount": "LPL", "t_stop_min": 1.8, "mass_kg": 1.36,
         "source_url": "https://www.arri.com/en/camera-systems/lenses/arri-signature-primes"},
        {"lens_id": "ARRI_SIG_75",  "manufacturer": "ARRI", "family": "Signature Prime",
         "focal_length_mm": 75,  "mount": "LPL", "t_stop_min": 1.8, "mass_kg": 1.63,
         "source_url": "https://www.arri.com/en/camera-systems/lenses/arri-signature-primes"},
        {"lens_id": "ARRI_SIG_125", "manufacturer": "ARRI", "family": "Signature Prime",
         "focal_length_mm": 125, "mount": "LPL", "t_stop_min": 1.8, "mass_kg": 2.30,
         "source_url": "https://www.arri.com/en/camera-systems/lenses/arri-signature-primes"},

        # ARRI Master Primes (PL)
        {"lens_id": "ARRI_MP_21", "manufacturer": "ARRI", "family": "Master Prime",
         "focal_length_mm": 21, "mount": "PL", "t_stop_min": 1.3, "mass_kg": 1.95,
         "source_url": "https://www.arri.com/en/camera-systems/lenses/arri-master-primes"},
        {"lens_id": "ARRI_MP_50", "manufacturer": "ARRI", "family": "Master Prime",
         "focal_length_mm": 50, "mount": "PL", "t_stop_min": 1.3, "mass_kg": 1.65,
         "source_url": "https://www.arri.com/en/camera-systems/lenses/arri-master-primes"},

        # Cooke S4/i (PL)
        {"lens_id": "COOKE_S4_25",  "manufacturer": "Cooke", "family": "S4/i",
         "focal_length_mm": 25,  "mount": "PL", "t_stop_min": 2.0, "mass_kg": 1.66,
         "source_url": "https://www.cookeoptics.com/lenses/s4-i/"},
        {"lens_id": "COOKE_S4_50",  "manufacturer": "Cooke", "family": "S4/i",
         "focal_length_mm": 50,  "mount": "PL", "t_stop_min": 2.0, "mass_kg": 1.60,
         "source_url": "https://www.cookeoptics.com/lenses/s4-i/"},
        {"lens_id": "COOKE_S4_100", "manufacturer": "Cooke", "family": "S4/i",
         "focal_length_mm": 100, "mount": "PL", "t_stop_min": 2.0, "mass_kg": 2.00,
         "source_url": "https://www.cookeoptics.com/lenses/s4-i/"},

        # Zeiss Supreme Primes (LPL)
        {"lens_id": "ZEISS_SP_25", "manufacturer": "Zeiss", "family": "Supreme Prime",
         "focal_length_mm": 25, "mount": "LPL", "t_stop_min": 1.5, "mass_kg": 1.38,
         "source_url": "https://www.zeiss.com/consumer-products/int/cinematography/lenses/supreme-prime-lenses.html"},
        {"lens_id": "ZEISS_SP_50", "manufacturer": "Zeiss", "family": "Supreme Prime",
         "focal_length_mm": 50, "mount": "LPL", "t_stop_min": 1.5, "mass_kg": 1.25,
         "source_url": "https://www.zeiss.com/consumer-products/int/cinematography/lenses/supreme-prime-lenses.html"},
    ]

    for ln in lenses:
        ln.setdefault("notes", "COM TBD — measure physically at GATE-MASS")
        db.upsert_lens("seed", ln)
        print(f"  {ln['lens_id']}")
