"""db/seed/cameras.py — Camera body seed data."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from db.schema import PhysicsDB


def seed(db: PhysicsDB):
    cameras = [
        {"camera_id": "ARRI_ALEXA_MINI_LF",
         "manufacturer": "ARRI", "model": "Alexa Mini LF",
         "mount": "LPL", "body_mass_kg": 2.8,
         "sensor_format": "LF 44x33mm",
         "source_url": "https://www.arri.com/en/camera-systems/cameras/alexa-mini-lf"},

        {"camera_id": "PHANTOM_FLEX_4K",
         "manufacturer": "Phantom", "model": "Flex 4K",
         "mount": "PL", "body_mass_kg": 9.0,
         "sensor_format": "Super 35",
         "source_url": "https://www.phantomhighspeed.com/cameras/flex4k",
         "notes": "Heavy — verify payload margin per robot before mounting."},

        {"camera_id": "SONY_VENICE_RIALTO",
         "manufacturer": "Sony", "model": "Venice Rialto",
         "mount": "PL", "body_mass_kg": 3.4,
         "sensor_format": "Full Frame",
         "source_url": "https://pro.sony/en_GB/products/digital-cinema-cameras/venice"},

        {"camera_id": "RED_MONSTRO_8K",
         "manufacturer": "RED", "model": "MONSTRO 8K VV",
         "mount": "PL", "body_mass_kg": 2.3,
         "sensor_format": "Full Frame VV",
         "source_url": "https://www.red.com/monstro"},
    ]

    for c in cameras:
        db.upsert_camera("seed", c)
        print(f"  {c['camera_id']}")
