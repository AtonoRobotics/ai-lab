"""db/seed/robots.py — Fleet registry seed data."""
import math, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from db.schema import PhysicsDB


def seed(db: PhysicsDB):
    robots = [
        {"robot_id": "R01", "name": "Dobot CR10",
         "arm_manufacturer": "Dobot", "arm_model": "CR10", "arm_model_confirmed": 1,
         "controller": "Dobot TCP/IP", "axes_count": 6,
         "payload_kg": 10.0, "reach_mm": 1525.0, "repeatability_mm": 0.02,
         "source_url": "https://www.dobot-robots.com/products/cr-series/cr10.html"},

        {"robot_id": "R02", "name": "MRMC Bolt #1",
         "arm_manufacturer": "Staubli", "arm_model": "RX160", "arm_model_confirmed": 1,
         "controller": "Flair + INtime + Hilscher EtherCAT + Ultibox",
         "axes_count": 6, "payload_kg": 20.0, "reach_mm": 1710.0, "repeatability_mm": 0.05,
         "source_url": "https://wiki.ros.org/staubli_rx160_support",
         "source_doc": "Staubli manual D28086504A"},

        {"robot_id": "R03", "name": "MRMC Bolt #2",
         "arm_manufacturer": "Staubli", "arm_model": "RX160", "arm_model_confirmed": 1,
         "controller": "Flair + INtime + Hilscher EtherCAT + Ultibox",
         "axes_count": 6, "payload_kg": 20.0, "reach_mm": 1710.0, "repeatability_mm": 0.05,
         "source_url": "https://wiki.ros.org/staubli_rx160_support",
         "source_doc": "Staubli manual D28086504A"},

        {"robot_id": "R04", "name": "MRMC Bolt #3",
         "arm_manufacturer": "Staubli", "arm_model": "RX160", "arm_model_confirmed": 1,
         "controller": "Flair + INtime + Hilscher EtherCAT + Ultibox",
         "axes_count": 6, "payload_kg": 20.0, "reach_mm": 1710.0, "repeatability_mm": 0.05,
         "source_url": "https://wiki.ros.org/staubli_rx160_support",
         "source_doc": "Staubli manual D28086504A"},

        {"robot_id": "R05", "name": "MRMC Bolt X",
         "arm_manufacturer": "Yaskawa", "arm_model": "GP20-HL", "arm_model_confirmed": 1,
         "controller": "Flair + YRC1000 (two-layer EtherCAT)",
         "axes_count": 6, "payload_kg": 20.0, "reach_mm": 1717.0, "repeatability_mm": 0.02,
         "source_url": "https://www.yaskawa.eu.com/products/robots/midrange-robots/gp20hl",
         "notes": "YRC1000 runs 0.5-1ms internal servo loop. Twin must model both layers."},

        {"robot_id": "R06", "name": "Camera Control Cobra",
         "arm_manufacturer": "Camera Control", "arm_model": "Cobra", "arm_model_confirmed": 1,
         "controller": "Flair EtherCAT", "axes_count": 6,
         "payload_kg": 16.0, "reach_mm": 3200.0,
         "source_url": "https://www.cameracontrol.com",
         "notes": "Contact jason@cameracontrol.com for spec confirmation."},

        {"robot_id": "R07", "name": "MRMC Modular",
         "arm_manufacturer": "MRMC", "arm_model": "Modular", "arm_model_confirmed": 1,
         "controller": "Flair",
         "source_url": "https://www.mrmoco.com",
         "notes": "Configurable axis count. Requires parametric Xacro URDF."},

        {"robot_id": "R08", "name": "MRMC Titan",
         "arm_manufacturer": "MRMC", "arm_model": "Titan", "arm_model_confirmed": 1,
         "controller": "Flair", "payload_kg": 45.0,
         "source_url": "https://www.mrmoco.com",
         "notes": "Telescopic/prismatic joint. NOT standard 6R. Custom IK required."},

        {"robot_id": "R09", "name": "Camera Control Black Mamba",
         "arm_manufacturer": "Camera Control", "arm_model": "Black Mamba", "arm_model_confirmed": 1,
         "controller": "Flair",
         "source_url": "https://www.cameracontrol.com",
         "notes": "All specs TBD. Contact jason@cameracontrol.com."},

        {"robot_id": "R10", "name": "MRMC Bolt Jr",
         "arm_manufacturer": "Mitsubishi", "arm_model": None, "arm_model_confirmed": 0,
         "controller": "Flair", "axes_count": 6,
         "payload_kg": 12.0, "reach_mm": 1200.0,
         "source_url": "https://www.mrmoco.com/motion-control/bolt-jr/",
         "notes": "BLOCKED: arm model unconfirmed. Read nameplate before pipeline."},

        {"robot_id": "TRK", "name": "MRMC Precision Track",
         "arm_manufacturer": "MRMC", "arm_model": "Precision Track", "arm_model_confirmed": 1,
         "controller": "Flair Axis 7 (linear)", "axes_count": 1,
         "source_url": "https://www.mrmoco.com"},
    ]

    source_rx160 = "staubli_rx160_support ROS pkg + Staubli manual D28086504A"
    rx160_joints = [
        # idx  a_m    d_m    alpha_rad      lower           upper          vel    effort
        (1, 0.000, 0.750, -math.pi/2, -math.pi,       math.pi,       3.927, 980),
        (2, 0.800, 0.000,  0.0,       -2.0595,         2.0595,        3.316, 980),
        (3, 0.000, 0.000, -math.pi/2, -math.pi,        1.22173,       3.316, 500),
        (4, 0.000, 0.910,  math.pi/2, -math.pi,        math.pi,       5.585, 210),
        (5, 0.000, 0.000, -math.pi/2, -2.26893,        2.26893,       5.585,  29),
        (6, 0.000, 0.140,  0.0,       -2*math.pi,  2*math.pi,         7.330, 110),
    ]
    rx160_links = [
        # idx  name        mass_kg  cx      cy      cz
        (0, "base_link",  21.82,  0.000,  0.000,  0.357),
        (1, "link1",      30.00,  0.000,  0.079, -0.094),
        (2, "link2",      20.00,  0.345,  0.011, -0.037),
        (3, "link3",       7.82,  0.000,  0.077,  0.062),
        (4, "link4",       4.15,  0.000,  0.000,  0.406),
        (5, "link5",       2.92,  0.000,  0.026, -0.024),
        (6, "link6",       0.95,  0.000,  0.000, -0.011),
    ]

    for r in robots:
        db.upsert_robot("seed", r)
        print(f"  {r['robot_id']}  {r['name']}")

    for rid in ["R02", "R03", "R04"]:
        for idx, a, d, alpha, lo, hi, vel, eff in rx160_joints:
            db.upsert_joint("seed", rid, idx, {
                "joint_name": f"joint{idx}", "joint_type": "revolute",
                "dh_a_m": a, "dh_d_m": d, "dh_alpha_rad": round(alpha, 6),
                "lower_limit": round(lo, 6), "upper_limit": round(hi, 6),
                "velocity_limit": vel, "effort_nm": eff,
                "physx_kp": 5000.0, "physx_kd": 500.0, "physx_friction": 20.0,
                "verified": 0,
                "notes": "kp/kd estimates — tune at GATE-PHY",
            }, source=source_rx160)

        for idx, name, mass, cx, cy, cz in rx160_links:
            db.upsert_link("seed", rid, idx, {
                "link_name": name, "mass_kg": mass,
                "com_x": cx, "com_y": cy, "com_z": cz,
                "verified": 0,
                "notes": "ROS wiki caveat: masses may not be accurate. Verify at GATE-MASS.",
            }, source=source_rx160)

    print(f"  RX160 joints+links seeded for R02, R03, R04")
