"""db/seed/decisions.py — Architecture Decision Records."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from db.schema import PhysicsDB


def seed(db: PhysicsDB):
    decisions = [
        ("ADR-001", "Database is single source of truth",
         "All physics data lives in fleet.db. Agents query PhysicsDB. No raw JSON files.",
         "JSON scatter caused data loss across sessions."),

        ("ADR-002", "validate_session.py runs before every session",
         "python agents/validate_session.py must pass before any other command.",
         "Prevents architecture drift across Claude Code sessions."),

        ("ADR-003", "AutoGen v0.4 (AG2) for multi-agent conversations",
         "Use AG2 fork: pip install autogen-agentchat autogen-ext[anthropic]",
         "Microsoft rewrite is mid-transition. AG2 is stable and Anthropic-compatible."),

        ("ADR-004", "MCP as the tool layer",
         "All external tools (web, Isaac Sim, PDF) are MCP servers. No hardcoded API calls.",
         "Standardised tool interface across Claude Code and AutoGen agents."),

        ("ADR-005", "7 blocking HITL gates — no exceptions",
         "GATE-DH, GATE-MASS, GATE-JLIM, GATE-COLL, GATE-USD, GATE-PHY, GATE-SAFE.",
         "Errors in DH params or safety zones cause hardware damage at 12m/s."),

        ("ADR-006", "URDF generated from CAD — not from manufacturer supply",
         "urdf-agent builds URDF from STL geometry. MRMC/Camera Control don't publish URDF.",
         "urdf_path is null until urdf-agent runs and GATE-DH approves."),

        ("ADR-007", "Staubli RX160 uses Modified DH convention (Craig)",
         "All RX160 joint parameters use Modified DH. Match ROS-Industrial convention.",
         "Any standard (classic) DH reference must be converted before DB entry."),

        ("ADR-008", "R10 Bolt Jr blocked until physical nameplate read",
         "arm_model_confirmed=0. Do not generate URDF or run simulation for R10.",
         "No public source confirms the Mitsubishi model. Nameplate is authoritative."),

        ("ADR-009", "PhysX kp/kd are placeholders until step response tuning",
         "All stiffness/damping values start as estimates (verified=0). Tune at GATE-PHY.",
         "Step response test in physics-agent produces the real values."),

        ("ADR-010", "GATE-SAFE requires physical set walkthrough — no remote approval",
         "Approver must walk the physical set. Record name + date in gate_approvals.",
         "Incorrect safety volumes at arm speeds cause irreversible damage."),
    ]

    for did, title, decision, rationale in decisions:
        db.record_decision(did, title, decision, rationale)
        print(f"  {did}  {title}")
