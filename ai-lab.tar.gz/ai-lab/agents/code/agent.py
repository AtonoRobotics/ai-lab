"""
agents/code/agent.py — Code Agent
Reviews agent code, generates patches, and validates changes
against ARCHITECTURE.md rules before writing anything.
"""
import sys, os, ast
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

BANNED_PATTERNS = [
    ("sqlite3.connect(",    "Use PhysicsDB — never call sqlite3.connect() directly"),
    ("knowledge_base/",     "knowledge_base/ is deprecated — use PhysicsDB"),
    ("open(",               "Avoid bare open() for DB files — use PhysicsDB"),
    ("verified=1",          "Never hardcode verified=1 — use db.approve_joints()"),
    ("json.dump",           "Physics data goes to DB, not JSON files"),
]

AGENT_FILES = [
    "agents/orchestrator.py",
    "agents/research/agent.py",
    "agents/urdf/agent.py",
    "agents/usd/agent.py",
    "agents/physics/agent.py",
    "agents/hitl/agent.py",
    "agents/code/agent.py",
    "db/schema.py",
]


def run(robot_id: str = None, db_path: str = "db/fleet.db"):
    """Entry point when called from orchestrator."""
    review_all()


def review_all():
    """Lint all agent files against architecture rules."""
    print("\n── Code Agent: Architecture Review ─────────────────")
    total_issues = 0

    for rel_path in AGENT_FILES:
        path = Path(rel_path)
        if not path.exists():
            print(f"  ⚠️   Missing: {rel_path}")
            continue

        issues = _review_file(path)
        if issues:
            print(f"\n  {rel_path}:")
            for line_no, msg in issues:
                print(f"    L{line_no}: {msg}")
            total_issues += len(issues)
        else:
            print(f"  ✅  {rel_path}")

    print(f"\n  Total issues: {total_issues}")
    return total_issues


def _review_file(path: Path) -> list:
    """Return list of (line_no, message) tuples for architecture violations."""
    issues = []
    try:
        source = path.read_text()
    except Exception as e:
        return [(0, f"Could not read file: {e}")]

    for line_no, line in enumerate(source.splitlines(), 1):
        stripped = line.strip()
        if stripped.startswith("#"):
            continue
        for pattern, msg in BANNED_PATTERNS:
            # Skip the one legitimate use of sqlite3 (in schema.py itself)
            if pattern == "sqlite3.connect(" and path.name == "schema.py":
                continue
            # Skip json.dump in seed files (seeds write JSON for open questions)
            if pattern == "json.dump" and "seed" in str(path):
                continue
            if pattern in line:
                issues.append((line_no, f"{msg}  [{pattern!r}]"))

    # Syntax check
    try:
        ast.parse(source)
    except SyntaxError as e:
        issues.append((e.lineno or 0, f"SyntaxError: {e.msg}"))

    return issues


def patch_file(path: str, old: str, new: str, dry_run: bool = True) -> bool:
    """
    Replace `old` with `new` in a file.
    dry_run=True shows the diff without writing.
    Returns True if change was made (or would be made in dry_run).
    """
    p = Path(path)
    if not p.exists():
        print(f"❌  File not found: {path}")
        return False

    source = p.read_text()
    if old not in source:
        print(f"❌  Pattern not found in {path}")
        return False

    patched = source.replace(old, new, 1)

    # Syntax check the patch
    try:
        ast.parse(patched)
    except SyntaxError as e:
        print(f"❌  Patch would introduce syntax error: {e}")
        return False

    # Architecture check the patch
    issues = []
    for line_no, line in enumerate(patched.splitlines(), 1):
        for pattern, msg in BANNED_PATTERNS:
            if pattern in line and not line.strip().startswith("#"):
                issues.append((line_no, msg))
    if issues:
        print(f"❌  Patch violates architecture rules:")
        for line_no, msg in issues:
            print(f"    L{line_no}: {msg}")
        return False

    if dry_run:
        print(f"  DRY RUN — would patch {path}:")
        print(f"  - {old[:80]!r}")
        print(f"  + {new[:80]!r}")
        return True

    p.write_text(patched)
    print(f"  ✅  Patched: {path}")
    return True


if __name__ == "__main__":
    review_all()
