"""
agents/urdf/agent.py — URDF Agent
Generates URDF from STL geometry + approved DB data.
Raises gates: GATE-DH, GATE-MASS, GATE-JLIM, GATE-COLL
Only reads verified=1 data (or all data if nothing verified yet).
"""
import sys, os
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from db.schema import PhysicsDB


MATERIAL_DENSITY = {"steel": 7850.0, "aluminium": 2700.0}

URDF_TEMPLATE = """<?xml version="1.0"?>
<robot name="{name}">
{links}
{joints}
</robot>
"""

LINK_TEMPLATE = """  <link name="{name}">
    <inertial>
      <mass value="{mass}"/>
      <origin xyz="{cx} {cy} {cz}"/>
      <inertia ixx="{ixx}" iyy="{iyy}" izz="{izz}" ixy="0" ixz="0" iyz="0"/>
    </inertial>{visual}{collision}
  </link>"""

JOINT_TEMPLATE = """  <joint name="{name}" type="{jtype}">
    <parent link="{parent}"/>
    <child link="{child}"/>
    <origin xyz="{ox} {oy} {oz}" rpy="{rx} {ry} {rz}"/>
    <axis xyz="{ax} {ay} {az}"/>
    <limit lower="{lo}" upper="{hi}" velocity="{vel}" effort="{eff}"/>
  </joint>"""


def run(robot_id: str, db_path: str = "db/fleet.db"):
    db = PhysicsDB(db_path)
    robot = db.get_robot(robot_id)

    if not robot:
        print(f"❌  {robot_id} not in database"); db.close(); return

    if not robot["arm_model_confirmed"]:
        print(f"❌  {robot_id} BLOCKED — arm model unconfirmed"); db.close(); return

    print(f"\n── URDF Agent: {robot_id} — {robot['name']} ─────────")

    data = db.export_for_urdf(robot_id)

    if not data["joints"]:
        _raise_gate("GATE-DH", robot_id,
                    "No joint data. Run research agent first.")
        db.close(); return

    if not data["all_verified"]:
        print("  ⚠️  Some data is unverified (verified=0). Will generate but flag.")

    # Check for special robot types
    if robot_id == "R08":
        print("  ⚠️  R08 Titan: prismatic joint — custom URDF path required")
        _generate_titan_stub(robot, db)
        db.close(); return

    if robot_id == "R07":
        print("  ⚠️  R07 Modular: parametric — Xacro generation required")
        db.close(); return

    urdf = _build_urdf(data)
    out_dir = Path("shared/artifacts") / robot_id
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"{robot_id}.urdf"
    out_path.write_text(urdf)
    print(f"  ✅  URDF written: {out_path}")

    # Update DB
    db._conn.execute(
        "UPDATE robots SET urdf_path=?, updated_at=datetime('now') WHERE robot_id=?",
        (str(out_path), robot_id)
    )
    db._conn.commit()

    if not data["all_verified"]:
        _raise_gate("GATE-DH", robot_id,
                    f"URDF generated from unverified data. Human must review DH parameters.")

    db.close()


def _build_urdf(data: dict) -> str:
    robot  = data["robot"]
    joints = data["joints"]
    links  = data["links"]
    name   = robot["arm_model"] or robot["name"]

    link_xml = []
    for l in links:
        ixx = l.get("ixx") or 0.001
        iyy = l.get("iyy") or 0.001
        izz = l.get("izz") or 0.001
        mesh_path = l.get("visual_mesh", "")
        visual = ""
        if mesh_path and Path(mesh_path).exists():
            visual = f'\n    <visual><geometry><mesh filename="{mesh_path}"/></geometry></visual>'
        link_xml.append(LINK_TEMPLATE.format(
            name=l["link_name"],
            mass=round(l.get("mass_kg") or 1.0, 4),
            cx=l.get("com_x") or 0, cy=l.get("com_y") or 0, cz=l.get("com_z") or 0,
            ixx=ixx, iyy=iyy, izz=izz,
            visual=visual, collision=""
        ))

    joint_xml = []
    for i, j in enumerate(joints):
        parent = links[i]["link_name"]   if i < len(links) else f"link{i}"
        child  = links[i+1]["link_name"] if i+1 < len(links) else f"link{i+1}"
        joint_xml.append(JOINT_TEMPLATE.format(
            name=j["joint_name"] or f"joint{j['joint_index']}",
            jtype=j["joint_type"],
            parent=parent, child=child,
            ox=j.get("dh_a_m") or 0,
            oy=0,
            oz=j.get("dh_d_m") or 0,
            rx=j.get("dh_alpha_rad") or 0, ry=0, rz=0,
            ax=0, ay=0, az=1,
            lo=round(j.get("lower_limit") or -3.14, 4),
            hi=round(j.get("upper_limit") or  3.14, 4),
            vel=j.get("velocity_limit") or 1.0,
            eff=j.get("effort_nm") or 100.0,
        ))

    return URDF_TEMPLATE.format(
        name=name,
        links="\n".join(link_xml),
        joints="\n".join(joint_xml)
    )


def _raise_gate(gate_id: str, robot_id: str, reason: str):
    import json
    pending = Path("shared/decisions/pending_gates.yaml")
    pending.parent.mkdir(parents=True, exist_ok=True)
    print(f"\n  🚧  {gate_id} raised for {robot_id}")
    print(f"  Reason: {reason}")
    print(f"  Approve: python agents/orchestrator.py --approve {gate_id} "
          f"--robot {robot_id} --notes \"<your notes>\"")
    entry = {"gate_id": gate_id, "robot_id": robot_id, "reason": reason}
    existing = []
    if pending.exists():
        import yaml
        try:
            existing = yaml.safe_load(pending.read_text()) or []
        except Exception:
            existing = []
    existing.append(entry)
    pending.write_text(json.dumps(existing, indent=2))


def _generate_titan_stub(robot, db):
    out = Path("shared/artifacts/R08/R08_titan_notes.txt")
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        "R08 MRMC Titan — Custom URDF required\n"
        "Reason: telescopic arm with PRISMATIC joint\n"
        "Standard 6R IK solvers do not apply\n"
        "Action: manual URDF authoring after CAD inspection\n"
    )
    print(f"  Notes written: {out}")
