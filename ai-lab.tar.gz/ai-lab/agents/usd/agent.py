"""
agents/usd/agent.py — USD Agent
Converts URDF to USD for Isaac Sim. Reads isaac_config.json to determine
whether to use Isaac Sim Docker, host install, or offline skeleton mode.
Raises gate: GATE-USD
"""
import sys, json, subprocess
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from db.schema import PhysicsDB

CONFIG_PATH = Path("agents/usd/isaac_config.json")

DEFAULT_CONFIG = {
    "mode": "OFFLINE",
    "notes": "No isaac_config.json found. Run install/07_isaac_sim.sh."
}

PHYSX_DEFAULTS = {
    "physx_kp":       5000.0,
    "physx_kd":        500.0,
    "physx_friction":   20.0,
    "physx_max_force": None,   # falls back to effort_nm
}


def run(robot_id: str, db_path: str = "db/fleet.db"):
    db  = PhysicsDB(db_path)
    cfg = _load_config()

    robot = db.get_robot(robot_id)
    if not robot:
        print(f"❌  {robot_id} not in database"); db.close(); return

    if not robot["urdf_path"] or not Path(robot["urdf_path"]).exists():
        print(f"❌  No URDF for {robot_id}. Run urdf agent first."); db.close(); return

    print(f"\n── USD Agent: {robot_id} ({cfg['mode']} mode) ───────────")

    urdf_path = robot["urdf_path"]
    out_dir   = Path("shared/artifacts") / robot_id
    out_dir.mkdir(parents=True, exist_ok=True)
    usd_path  = out_dir / f"{robot_id}.usd"

    if cfg["mode"] == "FULL":
        _convert_full(robot_id, urdf_path, usd_path, cfg, db)
    elif cfg["mode"] == "DOCKER":
        _convert_docker(robot_id, urdf_path, usd_path, cfg, db)
    else:
        _convert_offline(robot_id, urdf_path, usd_path, db)

    # Update DB
    if usd_path.exists():
        db._conn.execute(
            "UPDATE robots SET usd_path=?, updated_at=datetime('now') WHERE robot_id=?",
            (str(usd_path), robot_id)
        )
        db._conn.commit()
        print(f"  ✅  USD path recorded in DB: {usd_path}")

    _raise_gate("GATE-USD", robot_id, "Human review required before Isaac Sim import")
    db.close()


def _load_config() -> dict:
    if CONFIG_PATH.exists():
        return json.loads(CONFIG_PATH.read_text())
    return DEFAULT_CONFIG


def _convert_full(robot_id, urdf_path, usd_path, cfg, db):
    """Use host Isaac Sim Python to convert URDF → USD."""
    isaac_python = cfg.get("isaac_python_cmd", "/isaac-sim/python.sh")
    script = Path("agents/usd/convert_urdf.py")
    if not script.exists():
        _write_convert_script(script)
    cmd = [isaac_python, str(script),
           "--urdf", urdf_path, "--usd", str(usd_path)]
    print(f"  Running: {' '.join(cmd)}")
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode == 0:
        print(f"  ✅  USD generated: {usd_path}")
    else:
        print(f"  ❌  Conversion failed:\n{result.stderr}")


def _convert_docker(robot_id, urdf_path, usd_path, cfg, db):
    """Run URDF→USD conversion inside Isaac Sim Docker container."""
    image = cfg.get("isaac_sim_image", "nvcr.io/nvidia/isaac-sim:4.5.0")
    python = cfg.get("isaac_python_cmd", "/isaac-sim/python.sh")
    script = Path("agents/usd/convert_urdf.py")
    if not script.exists():
        _write_convert_script(script)

    project_root = Path.cwd().resolve()
    cmd = [
        "docker", "run", "--rm",
        "--runtime=nvidia", "--gpus", "all",
        "-e", "ACCEPT_EULA=Y",
        "-e", "PRIVACY_CONSENT=Y",
        "--network=host",
        "-v", f"{project_root}:/workspace",
        "-w", "/workspace",
        image,
        python, f"agents/usd/convert_urdf.py",
        "--urdf", urdf_path, "--usd", str(usd_path),
    ]
    print(f"  Docker: {image}")
    print(f"  Running conversion...")
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
    if result.returncode == 0:
        print(f"  ✅  USD generated: {usd_path}")
    else:
        print(f"  ❌  Docker conversion failed:\n{result.stderr[-500:]}")
        _convert_offline(robot_id, urdf_path, usd_path, db)


def _convert_offline(robot_id, urdf_path, usd_path, db):
    """Generate a JSON skeleton when Isaac Sim is unavailable."""
    joints = db.get_joints(robot_id)
    skeleton = {
        "schema": "usd_skeleton_v1",
        "robot_id": robot_id,
        "urdf_source": str(urdf_path),
        "mode": "OFFLINE",
        "joints": [
            {"name": j["joint_name"], "type": j["joint_type"],
             "kp": j.get("physx_kp") or PHYSX_DEFAULTS["physx_kp"],
             "kd": j.get("physx_kd") or PHYSX_DEFAULTS["physx_kd"],
             "verified": j["verified"]}
            for j in joints
        ],
        "note": "Import into Isaac Sim manually when available."
    }
    skel_path = usd_path.with_suffix(".skeleton.json")
    skel_path.write_text(json.dumps(skeleton, indent=2))
    print(f"  ✅  Offline skeleton: {skel_path}")


def _write_convert_script(path: Path):
    """Write the Isaac Sim Python conversion script."""
    path.write_text('''#!/usr/bin/env python3
"""convert_urdf.py — Run inside Isaac Sim Python to convert URDF → USD."""
import argparse
from omni.isaac.kit import SimulationApp
app = SimulationApp({"headless": True})

from omni.isaac.urdf import _urdf
from omni.isaac.core.utils.extensions import enable_extension
enable_extension("omni.isaac.urdf")

ap = argparse.ArgumentParser()
ap.add_argument("--urdf", required=True)
ap.add_argument("--usd",  required=True)
args = ap.parse_args()

cfg = _urdf.ImportConfig()
cfg.merge_fixed_joints = False
cfg.fix_base = True
cfg.self_collision = False

result, prim_path = _urdf.import_robot(args.urdf, "/World", cfg)
if result:
    import omni.usd
    omni.usd.get_context().save_as_stage(args.usd)
    print(f"Saved: {args.usd}")
else:
    print("URDF import failed")
    exit(1)
app.close()
''')


def _raise_gate(gate_id: str, robot_id: str, reason: str):
    pending = Path("shared/decisions/pending_gates.yaml")
    pending.parent.mkdir(parents=True, exist_ok=True)
    print(f"\n  🚧  {gate_id} raised for {robot_id}: {reason}")
    print(f"  Approve: python agents/orchestrator.py --approve {gate_id} --robot {robot_id}")
    entry = {"gate_id": gate_id, "robot_id": robot_id, "reason": reason}
    existing = []
    if pending.exists():
        try:
            existing = json.loads(pending.read_text()) or []
        except Exception:
            existing = []
    existing.append(entry)
    pending.write_text(json.dumps(existing, indent=2))
