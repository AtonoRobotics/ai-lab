"""
agents/orchestrator.py — Pipeline entry point
Routes tasks to the correct agent. Records gate approvals.
Usage:
    python agents/orchestrator.py --status
    python agents/orchestrator.py --task pipeline --robot R02
    python agents/orchestrator.py --approve GATE-DH --robot R02 --notes "verified"
    python agents/orchestrator.py --list-robots
"""
import argparse, sys, json
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from db.schema import PhysicsDB

DB_PATH = "db/fleet.db"

GATES = ["GATE-DH", "GATE-MASS", "GATE-JLIM", "GATE-COLL",
         "GATE-USD", "GATE-PHY", "GATE-SAFE"]

PIPELINE_STAGES = [
    ("research",  "Research datasheets and populate knowledge base"),
    ("urdf",      "Generate URDF from STL + approved KB data"),
    ("usd",       "Convert URDF to USD for Isaac Sim"),
    ("physics",   "Run validation tests"),
    ("hitl",      "Present pending gates for human review"),
]


def cmd_status(db: PhysicsDB, args):
    print("\n── Fleet Status ─────────────────────────────────")
    for r in db.all_robots():
        confirmed = "✅" if r["arm_model_confirmed"] else "⚠️  UNCONFIRMED"
        urdf = "URDF✅" if r["urdf_path"] else "URDF○"
        usd  = "USD✅"  if r["usd_path"]  else "USD○"
        print(f"  {r['robot_id']}  {r['name']:<28} {str(r['arm_model']):<14} "
              f"{confirmed}  {urdf}  {usd}")

    print("\n── Gate Approvals ───────────────────────────────")
    rows = db._conn.execute(
        "SELECT gate_id, robot_id, approved_at, approved_by FROM gate_approvals "
        "ORDER BY id"
    ).fetchall()
    if rows:
        for row in rows:
            print(f"  {row['gate_id']:<12} {row['robot_id']}  "
                  f"{row['approved_by']}  {row['approved_at'][:10]}")
    else:
        print("  No gates approved yet")
    print()


def cmd_list_robots(db: PhysicsDB, args):
    for r in db.all_robots():
        flag = "" if r["arm_model_confirmed"] else "  ⚠️  BLOCKED — read nameplate"
        print(f"  {r['robot_id']}  {r['name']}{flag}")


def cmd_approve(db: PhysicsDB, args):
    gate    = args.gate
    robot   = args.robot
    approver = args.approver or input("Your name: ").strip()
    notes   = args.notes or ""

    if gate not in GATES:
        print(f"❌  Unknown gate: {gate}. Valid: {', '.join(GATES)}")
        sys.exit(1)

    robot_row = db.get_robot(robot)
    if not robot_row:
        print(f"❌  Robot {robot} not in database")
        sys.exit(1)

    # Record approval
    db._conn.execute(
        "INSERT INTO gate_approvals(gate_id,robot_id,approved_at,approved_by,notes) "
        "VALUES(?,?,datetime('now'),?,?)",
        (gate, robot, approver, notes)
    )

    # Mark data as verified for DH/MASS gates
    if gate == "GATE-DH":
        db.approve_joints(robot, gate, approver, notes)
    if gate == "GATE-MASS":
        db.approve_links(robot, gate, approver, notes)

    db._conn.commit()
    print(f"✅  {gate} approved for {robot} by {approver}")

    # Append to decisions log
    with open("decisions_log.md", "a") as f:
        f.write(f"\n## {gate} — {robot} — approved by {approver}\n")
        f.write(f"Notes: {notes}\n")


def cmd_task(db: PhysicsDB, args):
    robot = args.robot
    if not db.get_robot(robot):
        print(f"❌  Robot {robot} not found"); sys.exit(1)

    r = db.get_robot(robot)
    if not r["arm_model_confirmed"]:
        print(f"❌  {robot} is BLOCKED — arm model unconfirmed. Read nameplate first.")
        sys.exit(1)

    task = args.task
    print(f"\n── Running: {task} for {robot} ─────────────────")

    if task == "pipeline":
        for stage, desc in PIPELINE_STAGES:
            print(f"\n  Stage: {stage} — {desc}")
            _run_agent(stage, robot, args)
    else:
        _run_agent(task, robot, args)


def _run_agent(name: str, robot_id: str, args):
    """Import and run the named agent."""
    try:
        mod = __import__(f"agents.{name}.agent", fromlist=["run"])
        mod.run(robot_id=robot_id)
    except ImportError as e:
        print(f"  ⚠️  Agent '{name}' not available: {e}")
    except Exception as e:
        print(f"  ❌  Agent '{name}' error: {e}")
        raise


def main():
    ap = argparse.ArgumentParser(description="Cinema Robot Twin Orchestrator")
    sub = ap.add_subparsers(dest="cmd")

    sub.add_parser("status",       help="Show fleet and gate status")
    sub.add_parser("list-robots",  help="List all robots")

    p_task = sub.add_parser("task", help="Run a pipeline stage")
    p_task.add_argument("--task",  required=True,
                        choices=["pipeline"] + [s for s,_ in PIPELINE_STAGES])
    p_task.add_argument("--robot", required=True)

    p_gate = sub.add_parser("approve", help="Record a gate approval")
    p_gate.add_argument("--gate",     required=True, choices=GATES)
    p_gate.add_argument("--robot",    required=True)
    p_gate.add_argument("--approver", default="")
    p_gate.add_argument("--notes",    default="")

    # Legacy flat args (--status, --approve etc.)
    ap.add_argument("--status",       action="store_true")
    ap.add_argument("--list-robots",  action="store_true", dest="list_robots")
    ap.add_argument("--approve",      metavar="GATE")
    ap.add_argument("--robot",        default="")
    ap.add_argument("--approver",     default="")
    ap.add_argument("--notes",        default="")
    ap.add_argument("--task",         default="")

    args = ap.parse_args()
    db = PhysicsDB(DB_PATH)

    # Support both subcommand and flat styles
    if args.status or getattr(args, "cmd", None) == "status":
        cmd_status(db, args)
    elif args.list_robots or getattr(args, "cmd", None) == "list-robots":
        cmd_list_robots(db, args)
    elif args.approve:
        args.gate = args.approve
        cmd_approve(db, args)
    elif getattr(args, "cmd", None) == "approve":
        cmd_approve(db, args)
    elif args.task or getattr(args, "cmd", None) == "task":
        cmd_task(db, args)
    else:
        ap.print_help()

    db.close()


if __name__ == "__main__":
    main()
