"""
agents/research/agent.py — Research Agent
Searches for robot specs, extracts from PDFs, writes to DB.
All writes require source citation. Flags missing data for HITL.
"""
import sys, json
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from db.schema import PhysicsDB

ROBOT_TARGETS = {
    "R01": {"query": "Dobot CR10 DH parameters joint limits datasheet"},
    "R02": {"query": "Staubli RX160 DH parameters joint limits manual D28086504A"},
    "R03": {"query": "Staubli RX160 DH parameters joint limits manual D28086504A"},
    "R04": {"query": "Staubli RX160 DH parameters joint limits manual D28086504A"},
    "R05": {"query": "Yaskawa GP20-HL DH parameters joint limits datasheet"},
    "R06": {"query": "Camera Control Cobra robot arm specifications reach payload"},
    "R07": {"query": "MRMC Modular robot arm specifications"},
    "R08": {"query": "MRMC Titan robot arm telescopic prismatic joint specifications"},
    "R09": {"query": "Camera Control Black Mamba robot arm specifications"},
    "R10": {"query": "BLOCKED — arm model unconfirmed. Read nameplate first.", "blocked": True},
    "TRK": {"query": "MRMC Precision Track linear axis specifications speed"},
}


def run(robot_id: str, db_path: str = "db/fleet.db"):
    db = PhysicsDB(db_path)
    target = ROBOT_TARGETS.get(robot_id)

    if not target:
        print(f"❌  No research target defined for {robot_id}")
        db.close()
        return

    if target.get("blocked"):
        print(f"❌  {robot_id} is BLOCKED: {target['query']}")
        db.close()
        return

    robot = db.get_robot(robot_id)
    if not robot:
        print(f"❌  {robot_id} not found in database")
        db.close()
        return

    print(f"\n── Research: {robot_id} — {robot['name']} ──────────────")
    print(f"  Query: {target['query']}")

    # Try AutoGen + MCP web search if available
    try:
        _run_with_autogen(robot_id, target["query"], db)
    except ImportError:
        print("  ⚠️  AutoGen not installed — running stub mode")
        _run_stub(robot_id, target["query"], db)

    db.close()


def _run_with_autogen(robot_id: str, query: str, db: PhysicsDB):
    """Full research via AutoGen + web search MCP."""
    from autogen_agentchat.agents import AssistantAgent
    from autogen_ext.models.anthropic import AnthropicChatCompletionClient

    import os
    client = AnthropicChatCompletionClient(
        model=os.environ.get("AGENT_MODEL", "claude-sonnet-4-20250514"),
        api_key=os.environ.get("ANTHROPIC_API_KEY", ""),
    )

    system = f"""You are a robotics research agent.
Your job: find DH parameters, joint limits, masses, and inertia for robot {robot_id}.
Query: {query}

Rules:
- Every value you report MUST have a source URL or document name
- If you cannot find a value with a source, say so explicitly — do not guess
- Output a JSON block with this structure:
  {{"joints": [{{"index": 1, "a_m": 0.0, "d_m": 0.75, ...}}],
    "links":  [{{"index": 0, "mass_kg": 21.82, ...}}],
    "open_questions": ["..."]}}
"""

    agent = AssistantAgent(
        name="research_agent",
        model_client=client,
        system_message=system,
    )

    # In a real session this would run a full AutoGen conversation
    # For now, print the research intent
    print(f"  AutoGen research agent ready for: {robot_id}")
    print(f"  Start interactive session: run autogen conversation loop")


def _run_stub(robot_id: str, query: str, db: PhysicsDB):
    """Stub mode: show what would be researched, output open questions."""
    robot = db.get_robot(robot_id)
    joints = db.get_joints(robot_id)
    links  = db.get_links(robot_id)

    print(f"  Current DB state:")
    print(f"    Joints: {len(joints)} ({sum(1 for j in joints if j['verified'])} verified)")
    print(f"    Links:  {len(links)}  ({sum(1 for l in links if l['verified'])} verified)")

    open_q = []
    if not joints:
        open_q.append(f"No DH parameters found — research needed: {query}")
    if not links:
        open_q.append("No link mass/inertia data — STL extraction or datasheet needed")
    if not robot["arm_model_confirmed"]:
        open_q.append("arm_model_confirmed=0 — read physical nameplate")

    if open_q:
        print("  Open questions:")
        for q in open_q:
            print(f"    ○ {q}")

        # Write to shared decisions folder
        out = Path("shared/decisions") / f"open_questions_{robot_id}.json"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps({"robot_id": robot_id, "questions": open_q}, indent=2))
        print(f"  Written: {out}")
    else:
        print("  No open questions — data looks complete")
