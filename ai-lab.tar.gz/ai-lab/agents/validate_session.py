"""
agents/validate_session.py — Session Start Enforcer
Run this before anything else every session.
Exit 0 = safe to proceed. Exit 1 = stop and fix.

Checks:
  1. ARCHITECTURE.md hash (detects unauthorised edits)
  2. fleet.db exists and has expected tables
  3. No verified=1 rows without a gate_approval record
  4. R10 Bolt Jr confirmation status (warning only)
"""
import sys, hashlib, sqlite3
from pathlib import Path

# ── Update this hash after any ARCHITECTURE.md amendment ──────────────────────
# Run: python agents/validate_session.py --print-hash
# Then paste the output here.
ARCHITECTURE_HASH = "BOOTSTRAP"   # set to "BOOTSTRAP" on first install

ARCH_FILE = Path("ARCHITECTURE.md")
DB_FILE   = Path("db/fleet.db")


def check_arch_hash() -> tuple[bool, str]:
    if not ARCH_FILE.exists():
        return False, "ARCHITECTURE.md not found"

    if ARCHITECTURE_HASH == "BOOTSTRAP":
        h = hashlib.sha256(ARCH_FILE.read_bytes()).hexdigest()
        return True, f"BOOTSTRAP mode — hash is {h[:16]}...\nRun: python agents/validate_session.py --print-hash"

    h = hashlib.sha256(ARCH_FILE.read_bytes()).hexdigest()
    if h == ARCHITECTURE_HASH:
        return True, f"Hash OK ({h[:16]}...)"
    return False, f"ARCHITECTURE.md has been modified without an ADR!\nExpected: {ARCHITECTURE_HASH[:16]}...\nGot:      {h[:16]}..."


def check_database() -> tuple[bool, str]:
    if not DB_FILE.exists():
        return False, f"{DB_FILE} not found — run: bash install/02_database.sh"

    try:
        conn = sqlite3.connect(str(DB_FILE))
        tables = {r[0] for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()}
        required = {"robots", "joints", "links", "gate_approvals",
                    "architecture_decisions", "audit_log"}
        missing = required - tables
        if missing:
            return False, f"Missing tables: {missing}"

        r_count = conn.execute("SELECT COUNT(*) FROM robots").fetchone()[0]
        conn.close()
        return True, f"{r_count} robots in fleet"
    except Exception as e:
        return False, f"DB error: {e}"


def check_integrity() -> tuple[bool, str]:
    """Verify no verified=1 rows exist without a gate_approval."""
    try:
        conn = sqlite3.connect(str(DB_FILE))
        verified_joints = conn.execute(
            "SELECT DISTINCT robot_id FROM joints WHERE verified=1"
        ).fetchall()

        orphans = []
        for (rid,) in verified_joints:
            approved = conn.execute(
                "SELECT id FROM gate_approvals WHERE robot_id=? AND gate_id='GATE-DH'",
                (rid,)
            ).fetchone()
            if not approved:
                orphans.append(rid)

        conn.close()
        if orphans:
            return False, f"verified=1 joints without GATE-DH approval: {orphans}"
        return True, "Integrity OK"
    except Exception as e:
        return False, f"Integrity check error: {e}"


def check_bolt_jr() -> tuple[bool, str]:
    """Warning-only check for R10."""
    try:
        conn = sqlite3.connect(str(DB_FILE))
        r10 = conn.execute(
            "SELECT arm_model_confirmed, arm_model FROM robots WHERE robot_id='R10'"
        ).fetchone()
        conn.close()
        if r10 and not r10[0]:
            return False, "R10 Bolt Jr arm model UNCONFIRMED — pipeline blocked until nameplate read"
        return True, "R10 confirmed" if r10 else "R10 not in DB"
    except Exception:
        return True, "R10 check skipped"


def main():
    if "--print-hash" in sys.argv:
        if ARCH_FILE.exists():
            h = hashlib.sha256(ARCH_FILE.read_bytes()).hexdigest()
            print(f'\nARCHITECTURE_HASH = "{h}"')
            print(f'\nPaste this into agents/validate_session.py line 20')
        else:
            print("ARCHITECTURE.md not found")
        sys.exit(0)

    width = 60
    print("=" * width)
    print("  SESSION VALIDATION — Cinema Robot Digital Twin")
    print("=" * width)

    checks = [
        ("ARCHITECTURE.md hash",  check_arch_hash,  "CRITICAL"),
        ("Database integrity",     check_database,   "CRITICAL"),
        ("DB row integrity",       check_integrity,  "CRITICAL"),
        ("R10 Bolt Jr status",     check_bolt_jr,    "WARNING"),
    ]

    failed_critical = False

    for label, fn, level in checks:
        ok, msg = fn()
        icon = "✅" if ok else ("⚠️ " if level == "WARNING" else "❌")
        print(f"\n  {icon}  {label}")
        for line in msg.splitlines():
            print(f"       {line}")
        if not ok and level == "CRITICAL":
            failed_critical = True

    print("\n" + "=" * width)
    if failed_critical:
        print("  ❌  FAILED — fix issues above before proceeding")
        print("=" * width + "\n")
        sys.exit(1)
    else:
        print("  ✅  ALL CHECKS PASSED — safe to proceed")
        print("=" * width + "\n")
        sys.exit(0)


if __name__ == "__main__":
    main()
