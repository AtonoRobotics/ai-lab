"""
agents/physics/agent.py — Physics Validation Agent
Runs kinematic, dynamic, and step response tests.
Raises gate: GATE-PHY
"""
import sys, json, math
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from db.schema import PhysicsDB


def run(robot_id: str, db_path: str = "db/fleet.db"):
    db = PhysicsDB(db_path)
    robot = db.get_robot(robot_id)

    if not robot:
        print(f"❌  {robot_id} not in database"); db.close(); return
    if not robot["usd_path"]:
        print(f"❌  No USD for {robot_id}. Run USD agent first."); db.close(); return

    print(f"\n── Physics Agent: {robot_id} ────────────────────────")

    results = {}
    results["kinematics"]  = _test_kinematics(robot_id, db)
    results["joint_limits"] = _test_joint_limits(robot_id, db)
    results["dynamics"]    = _test_dynamics(robot_id, db)

    _write_report(robot_id, results)

    passed = all(r["pass"] for r in results.values())
    if passed:
        print(f"  ✅  All tests passed — GATE-PHY ready for human review")
    else:
        failed = [k for k, v in results.items() if not v["pass"]]
        print(f"  ❌  Failed: {', '.join(failed)}")

    _raise_gate("GATE-PHY", robot_id,
                "Review physics test report before approving simulation.")
    db.close()


def _test_kinematics(robot_id: str, db: PhysicsDB) -> dict:
    """Check DH chain produces a plausible reach."""
    joints = db.get_joints(robot_id)
    if not joints:
        return {"pass": False, "msg": "No joints in database"}

    # Forward kinematics: sum of link lengths as rough reach estimate
    reach = sum(abs(j["dh_a_m"] or 0) + abs(j["dh_d_m"] or 0) for j in joints)
    robot = db.get_robot(robot_id)
    expected_reach_m = (robot["reach_mm"] or 0) / 1000.0

    ok = expected_reach_m == 0 or abs(reach - expected_reach_m) < expected_reach_m * 0.3
    msg = f"Estimated reach {reach:.3f}m vs spec {expected_reach_m:.3f}m"
    print(f"  {'✅' if ok else '⚠️ '} Kinematics: {msg}")
    return {"pass": ok, "msg": msg, "reach_m": round(reach, 4)}


def _test_joint_limits(robot_id: str, db: PhysicsDB) -> dict:
    """Verify all joints have finite, non-zero limits."""
    joints = db.get_joints(robot_id)
    issues = []
    for j in joints:
        lo = j["lower_limit"]
        hi = j["upper_limit"]
        if lo is None or hi is None:
            issues.append(f"J{j['joint_index']}: limits missing")
        elif lo >= hi:
            issues.append(f"J{j['joint_index']}: lower >= upper ({lo} >= {hi})")
        elif abs(hi - lo) < 0.001:
            issues.append(f"J{j['joint_index']}: range too small ({hi-lo:.4f} rad)")

    ok = len(issues) == 0
    msg = "All limits valid" if ok else f"{len(issues)} issue(s): {'; '.join(issues)}"
    print(f"  {'✅' if ok else '❌ '} Joint limits: {msg}")
    return {"pass": ok, "msg": msg}


def _test_dynamics(robot_id: str, db: PhysicsDB) -> dict:
    """Check total mass is plausible and kp/kd are non-zero."""
    links  = db.get_links(robot_id)
    joints = db.get_joints(robot_id)
    issues = []

    total_mass = sum(l["mass_kg"] or 0 for l in links)
    if total_mass < 1.0:
        issues.append(f"Total mass {total_mass:.1f}kg seems too low")

    for j in joints:
        if not j.get("physx_kp"):
            issues.append(f"J{j['joint_index']}: physx_kp not set")

    ok = len(issues) == 0
    msg = f"Total mass {total_mass:.1f}kg" if ok else "; ".join(issues)
    print(f"  {'✅' if ok else '⚠️ '} Dynamics: {msg}")
    return {"pass": ok, "msg": msg, "total_mass_kg": round(total_mass, 2)}


def _write_report(robot_id: str, results: dict):
    out = Path("shared/artifacts") / robot_id / "physics_report.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps({"robot_id": robot_id, "results": results}, indent=2))
    print(f"  Report: {out}")


def _raise_gate(gate_id: str, robot_id: str, reason: str):
    pending = Path("shared/decisions/pending_gates.yaml")
    pending.parent.mkdir(parents=True, exist_ok=True)
    print(f"\n  🚧  {gate_id} raised for {robot_id}: {reason}")
    print(f"  Approve: python agents/orchestrator.py --approve {gate_id} --robot {robot_id}")
    entry = {"gate_id": gate_id, "robot_id": robot_id, "reason": reason}
    existing = []
    if pending.exists():
        try:
            existing = json.loads(pending.read_text()) or []
        except Exception:
            existing = []
    existing.append(entry)
    pending.write_text(json.dumps(existing, indent=2))
