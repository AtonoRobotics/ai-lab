"""
agents/hitl/agent.py — Human-in-the-Loop Gate Agent
Presents pending gates clearly and captures the human decision.
All approvals are written to gate_approvals in fleet.db and decisions_log.md.
"""
import sys, json
from pathlib import Path
from datetime import datetime, timezone
sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from db.schema import PhysicsDB

PENDING_FILE = Path("shared/decisions/pending_gates.yaml")

GATE_INSTRUCTIONS = {
    "GATE-DH":   "Verify DH parameters match physical robot. Check axis directions on real arm.",
    "GATE-MASS": "Verify link masses against weighscale or CAD BOM. Check COM positions.",
    "GATE-JLIM": "Verify joint limits match controller limits. Check hard stops on real arm.",
    "GATE-COLL": "Verify collision meshes cover all robot surfaces. Test in Isaac Sim viewer.",
    "GATE-USD":  "Open USD in Isaac Sim. Verify visual, check for mesh errors, confirm PhysX.",
    "GATE-PHY":  "Run step response test in Isaac Sim. Tune kp/kd until tracking is accurate.",
    "GATE-SAFE": "Walk the physical set. Verify all No-Go zones are correct. Sign off on site.",
}


def run(robot_id: str = None, db_path: str = "db/fleet.db"):
    db = PhysicsDB(db_path)
    pending = _load_pending(robot_id)

    if not pending:
        print("\n── HITL Agent ─────────────────────────────────────")
        print("  No pending gates.")
        db.close()
        return

    print(f"\n── HITL Agent: {len(pending)} pending gate(s) ────────────────")

    for entry in pending:
        _present_gate(entry, db)

    db.close()


def _load_pending(robot_id: str = None) -> list:
    if not PENDING_FILE.exists():
        return []
    try:
        data = json.loads(PENDING_FILE.read_text()) or []
        if robot_id:
            data = [e for e in data if e.get("robot_id") == robot_id]
        return data
    except Exception:
        return []


def _present_gate(entry: dict, db: PhysicsDB):
    gate_id  = entry["gate_id"]
    robot_id = entry["robot_id"]
    reason   = entry.get("reason", "")

    print(f"""
  ┌─────────────────────────────────────────────────┐
  │  Gate:   {gate_id:<40} │
  │  Robot:  {robot_id:<40} │
  │  Reason: {reason[:40]:<40} │
  └─────────────────────────────────────────────────┘
  Instructions: {GATE_INSTRUCTIONS.get(gate_id, 'See ARCHITECTURE.md')}
""")

    # Show current data summary
    _show_data_summary(robot_id, gate_id, db)

    print("  Options:")
    print("    [A] Approve    [R] Reject    [S] Skip for now")
    choice = input("  > ").strip().upper()

    if choice == "A":
        approver = input("  Your name: ").strip()
        notes    = input("  Notes (optional): ").strip()
        _approve(gate_id, robot_id, approver, notes, db)
    elif choice == "R":
        reason   = input("  Reason for rejection: ").strip()
        _reject(gate_id, robot_id, reason, db)
    else:
        print("  Skipped.")


def _show_data_summary(robot_id: str, gate_id: str, db: PhysicsDB):
    if gate_id == "GATE-DH":
        joints = db.get_joints(robot_id)
        print(f"  Joints in DB: {len(joints)}")
        for j in joints[:3]:
            print(f"    J{j['joint_index']}: a={j['dh_a_m']}m  d={j['dh_d_m']}m  "
                  f"α={j['dh_alpha_rad']:.4f}  verified={j['verified']}")
        if len(joints) > 3:
            print(f"    ... and {len(joints)-3} more")
    elif gate_id == "GATE-MASS":
        links = db.get_links(robot_id)
        total = sum(l["mass_kg"] or 0 for l in links)
        print(f"  Links in DB: {len(links)} | Total mass: {total:.2f} kg")
    elif gate_id == "GATE-SAFE":
        print("  ⚠️  GATE-SAFE requires physical presence on set.")
        print("  No remote approval accepted. Walk the set first.")


def _approve(gate_id: str, robot_id: str, approver: str, notes: str, db: PhysicsDB):
    db._conn.execute(
        "INSERT INTO gate_approvals(gate_id,robot_id,approved_at,approved_by,notes) "
        "VALUES(?,?,?,?,?)",
        (gate_id, robot_id,
         datetime.now(timezone.utc).isoformat(), approver, notes)
    )
    if gate_id == "GATE-DH":
        db.approve_joints(robot_id, gate_id, approver, notes)
    if gate_id == "GATE-MASS":
        db.approve_links(robot_id, gate_id, approver, notes)
    db._conn.commit()

    _log(f"{gate_id} APPROVED — {robot_id} by {approver}. Notes: {notes}")
    _remove_from_pending(gate_id, robot_id)
    print(f"  ✅  {gate_id} approved for {robot_id}")


def _reject(gate_id: str, robot_id: str, reason: str, db: PhysicsDB):
    _log(f"{gate_id} REJECTED — {robot_id}. Reason: {reason}")
    _remove_from_pending(gate_id, robot_id)
    print(f"  ❌  {gate_id} rejected. Reason logged.")


def _log(msg: str):
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    with open("decisions_log.md", "a") as f:
        f.write(f"\n## {ts} — {msg}\n")


def _remove_from_pending(gate_id: str, robot_id: str):
    if not PENDING_FILE.exists():
        return
    try:
        data = json.loads(PENDING_FILE.read_text()) or []
        data = [e for e in data
                if not (e["gate_id"] == gate_id and e["robot_id"] == robot_id)]
        PENDING_FILE.write_text(json.dumps(data, indent=2))
    except Exception:
        pass
