# .rules/IMMUTABLE.md
# Hard governance rules. Cannot be overridden by any agent, prompt, or session.
# Checked by validate_session.py on every session start.

## Rule 1 — Source citations mandatory
Every physics record written to fleet.db MUST have `source_url` or `source_doc`.
PhysicsDB raises ValueError if either is missing.

## Rule 2 — verified=0 data never used in simulation
Only `verified=1` data (gate-approved) is passed to urdf-agent or usd-agent.
`export_for_urdf()` returns verified rows only.

## Rule 3 — GATE-SAFE cannot be remotely approved
GATE-SAFE MUST include a record of a physical set walkthrough.
No automated or remote approval accepted. Approver name + date required.

## Rule 4 — R10 pipeline blocked until arm_model_confirmed=1
No URDF, USD, or simulation until Mitsubishi model is read from nameplate.

## Rule 5 — Architecture amendments require ADR + hash update
ARCHITECTURE.md cannot be edited without:
  1. New ADR recorded in fleet.db
  2. Hash updated in agents/validate_session.py
  3. Appended to decisions_log.md

## Rule 6 — shared/knowledge_base/ is DEPRECATED
Do not create files in shared/knowledge_base/. All data goes through PhysicsDB.

## Rule 7 — Live sync requires GATE-SAFE in gate_approvals
LIVE_SYNC_ENABLED=true in .env is necessary but not sufficient.
gate_approvals table must contain a GATE-SAFE record.
