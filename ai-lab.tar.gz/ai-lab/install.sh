#!/usr/bin/env bash
# install.sh — Cinema Robot Digital Twin
# Runs all 4 sections in order. Safe to re-run.
#
# Usage:
#   bash install.sh             # full install
#   bash install.sh --only 02   # one section
#   bash install.sh --from 03   # resume from section

set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ONLY=""; FROM=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --only) ONLY="$2"; shift 2 ;;
    --from) FROM="$2"; shift 2 ;;
    *) shift ;;
  esac
done

run_section() {
  local id="$1" script="$ROOT/install/${id}_"*.sh
  [[ -n "$ONLY" && "$id" != "$ONLY" ]] && return 0
  [[ -n "$FROM" ]] && (( 10#$id < 10#$FROM )) && return 0
  echo -e "\n\033[1;34m── Section $id ──────────────────────────────\033[0m"
  bash $script
}

run_section 01
run_section 02
run_section 03
run_section 04

echo -e "\n\033[1;32m✅  Install complete → $ROOT\033[0m"
echo "   Next: cd ~/ai-lab && python agents/validate_session.py"
