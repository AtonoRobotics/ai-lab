# ARCHITECTURE.md — Cinema Robot Digital Twin
# STATUS: ENFORCED — hash-checked by validate_session.py every session
# To amend: follow Section 5 (Amendment Procedure)

---

## Section 0 — Session Start Protocol (mandatory)

```bash
cd ~/ai-lab
python agents/validate_session.py    # must pass before anything else
python agents/orchestrator.py --status
```

---

## Section 1 — Architecture Decisions

### ADR-001 — Database is single source of truth
**Decision:** All physics data lives in `db/fleet.db`. Agents query `PhysicsDB` (db/schema.py). No JSON files in shared/.
**Rationale:** JSON scatter across sessions caused data loss and contradictions between sessions.

### ADR-002 — validate_session.py runs before every session
**Decision:** `python agents/validate_session.py` must pass before any other command.
**Rationale:** Prevents architecture drift across Claude Code sessions. Hash check catches silent edits to this file.

### ADR-003 — AutoGen v0.4 (AG2) for multi-agent
**Decision:** Use AG2 fork: `pip install autogen-agentchat autogen-ext[anthropic]`
**Rationale:** Microsoft rewrite is mid-transition. AG2 is stable and works with Anthropic API.

### ADR-004 — MCP as the tool layer
**Decision:** External tools (web search, Isaac Sim, PDF) are MCP servers. No hardcoded API calls in agents.
**Rationale:** Standardised tool interface works across Claude Code and AutoGen agents.

### ADR-005 — 7 blocking HITL gates — no exceptions
**Decision:** GATE-DH, GATE-MASS, GATE-JLIM, GATE-COLL, GATE-USD, GATE-PHY, GATE-SAFE must all be approved before live sync.
**Rationale:** Robots move at 12 m/s. Incorrect DH params or safety volumes cause irreversible hardware damage.

### ADR-006 — URDF generated from CAD, not manufacturer supply
**Decision:** `urdf-agent` builds URDF from STL geometry. MRMC and Camera Control do not publish URDF.
**Rationale:** `urdf_path` is null until urdf-agent runs and GATE-DH approves.

### ADR-007 — Staubli RX160 uses Modified DH convention (Craig)
**Decision:** All RX160 DH parameters use Modified (Craig) convention. Match ROS-Industrial staubli_rx160_support.
**Rationale:** Any standard (classic) DH reference must be converted before entry into DB.

### ADR-008 — R10 Bolt Jr blocked until nameplate read in person
**Decision:** `arm_model_confirmed=0`. No URDF, USD, or simulation for R10 until Mitsubishi model confirmed from physical nameplate.
**Rationale:** No public source confirms the model. Guessing a wrong model invalidates all subsequent physics work.

### ADR-009 — PhysX kp/kd are placeholders until step response tuning
**Decision:** All stiffness/damping values start as estimates (`verified=0`). physics-agent tunes them at GATE-PHY.
**Rationale:** Manufacturer values don't account for end-effector load or cable stiffness.

### ADR-010 — GATE-SAFE requires physical set walkthrough — no remote approval
**Decision:** Approver must walk the physical set and confirm No-Go zones. Record name + date in `gate_approvals`.
**Rationale:** Incorrect safety volumes at arm speeds cause irreversible damage to crew, camera, and set.

---

## Section 2 — Inviolable Rules

Agents **MUST NEVER**:
1. Call `sqlite3.connect()` directly — always use `PhysicsDB`
2. Write physics data to JSON files — always write to DB
3. Set `verified=1` without a gate approval in `gate_approvals`
4. Generate URDF or USD from `verified=0` data without flagging GATE-DH
5. Enable live robot sync without GATE-SAFE in `gate_approvals`
6. Proceed past any gate without human approval
7. Guess R10 arm model — wait for nameplate
8. Modify ARCHITECTURE.md without recording an ADR first

---

## Section 3 — Data Flow

```
CAD/STL
  → research-agent  → DB (verified=0)
  → GATE-DH (human)
  → urdf-agent      → URDF (verified=1 joints)
  → GATE-MASS, GATE-JLIM, GATE-COLL
  → usd-agent       → USD
  → GATE-USD
  → physics-agent   → tuned kp/kd
  → GATE-PHY
  → TWIN ACTIVE
  → GATE-SAFE (physical walkthrough)
  → LIVE SYNC ENABLED
```

---

## Section 4 — Agent Roster

| Agent | File | Job |
|-------|------|-----|
| Orchestrator | `agents/orchestrator.py` | Routes tasks, records approvals |
| Research | `agents/research/agent.py` | Web/PDF lookup, populates DB |
| URDF | `agents/urdf/agent.py` | STL → URDF |
| USD | `agents/usd/agent.py` | URDF → Isaac Sim USD |
| Physics | `agents/physics/agent.py` | Validation tests, tunes kp/kd |
| HITL | `agents/hitl/agent.py` | Presents gates for human decision |
| Code | `agents/code/agent.py` | Reviews and patches agent code |

---

## Section 5 — Amendment Procedure

To change any decision in this document:

1. Record ADR in DB:
   ```python
   from db.schema import PhysicsDB
   db = PhysicsDB("db/fleet.db")
   db.record_decision("ADR-011", "title", "decision text", "rationale")
   ```

2. Edit this file

3. Update the hash in `agents/validate_session.py`:
   ```bash
   python agents/validate_session.py --print-hash
   # Paste output into ARCHITECTURE_HASH on line 20
   ```

4. Append to `decisions_log.md`

5. Commit `ARCHITECTURE.md` and `agents/validate_session.py` together

---

## Section 6 — R10 Bolt Jr Unblock Procedure

1. Read the physical nameplate on the robot arm (base or access panel)
2. Update DB:
   ```python
   db.upsert_robot("human", {
       "robot_id": "R10",
       "arm_model": "MELFA RV-12FR",   # replace with actual model
       "arm_model_confirmed": 1,
       "source_doc": "Physical nameplate read YYYY-MM-DD by [name]",
       "source_url": "https://www.mitsubishielectric.com/fa/products/..."
   })
   ```
3. Run research agent: `python agents/orchestrator.py --task research --robot R10`
