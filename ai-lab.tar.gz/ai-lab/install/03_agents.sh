#!/usr/bin/env bash
# 03_agents.sh — Create __init__.py files and validate agent imports
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

ok()   { echo "  ✅  $1"; }
warn() { echo "  ⚠️   $1"; }
fail() { echo "  ❌  $1"; exit 1; }

# ── Check agent files exist ───────────────────────────────────────────────────
AGENT_FILES=(
  "agents/orchestrator.py"
  "agents/research/agent.py"
  "agents/urdf/agent.py"
  "agents/usd/agent.py"
  "agents/physics/agent.py"
  "agents/hitl/agent.py"
  "agents/code/agent.py"
  "agents/validate_session.py"
)

for f in "${AGENT_FILES[@]}"; do
  [[ -f "$ROOT/$f" ]] && ok "$f" || fail "$f not found"
done

# ── Create __init__.py files ──────────────────────────────────────────────────
PACKAGES=(
  "db"
  "db/seed"
  "agents"
  "agents/research"
  "agents/urdf"
  "agents/usd"
  "agents/physics"
  "agents/hitl"
  "agents/code"
)

for pkg in "${PACKAGES[@]}"; do
  init="$ROOT/$pkg/__init__.py"
  [[ -f "$init" ]] || echo "" > "$init"
  ok "$pkg/__init__.py"
done

# ── Initialise decisions_log.md ───────────────────────────────────────────────
LOG="$ROOT/decisions_log.md"
[[ -f "$LOG" ]] || cat > "$LOG" << 'EOF'
# decisions_log.md — Gate Approvals & Architecture Decisions
# All HITL gate approvals are appended here by agents/hitl/agent.py

## Project initialised
EOF
ok "decisions_log.md"

# ── Validate imports ──────────────────────────────────────────────────────────
cd "$ROOT"
python3 - << 'PYEOF'
import sys
sys.path.insert(0, ".")
results = []
mods = [
    ("db.schema",           "PhysicsDB"),
    ("agents.research.agent", "research"),
    ("agents.urdf.agent",     "urdf"),
    ("agents.usd.agent",      "usd"),
    ("agents.physics.agent",  "physics"),
    ("agents.hitl.agent",     "hitl"),
    ("agents.code.agent",     "code"),
]
for mod, label in mods:
    try:
        __import__(mod)
        print(f"  ✅  {label} ({mod})")
    except ImportError as e:
        print(f"  ⚠️   {label} ({mod}): {e}")
    except Exception as e:
        print(f"  ❌  {label} ({mod}): {e}")
PYEOF

echo "  Section 03 done"
