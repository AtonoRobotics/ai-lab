#!/usr/bin/env bash
# 02_database.sh — Copy DB source files and seed fleet.db
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

ok()   { echo "  ✅  $1"; }
fail() { echo "  ❌  $1"; exit 1; }

python3 -c "import sys; assert sys.version_info >= (3,10)" 2>/dev/null \
  || fail "Python 3.10+ required"

# Copy source files (they live alongside the installer during setup)
mkdir -p "$ROOT/db/seed"

for f in schema.py; do
  [[ -f "$ROOT/db/$f" ]] && ok "db/$f exists" || fail "db/$f not found — copy it first"
done

for f in robots.py cameras.py lenses.py decisions.py; do
  [[ -f "$ROOT/db/seed/$f" ]] && ok "db/seed/$f exists" || fail "db/seed/$f not found"
done

# Seed the database
echo "  Seeding fleet.db..."
cd "$ROOT"
python3 - << 'PYEOF'
import sys
sys.path.insert(0, ".")
from db.schema import PhysicsDB
from db.seed import robots, cameras, lenses, decisions

db = PhysicsDB("db/fleet.db")

print("\n  Robots:")
robots.seed(db)

print("\n  Cameras:")
cameras.seed(db)

print("\n  Lenses:")
lenses.seed(db)

print("\n  Architecture decisions:")
decisions.seed(db)

# Quick sanity check
r  = db._conn.execute("SELECT COUNT(*) FROM robots").fetchone()[0]
j  = db._conn.execute("SELECT COUNT(*) FROM joints").fetchone()[0]
ln = db._conn.execute("SELECT COUNT(*) FROM lenses").fetchone()[0]
ad = db._conn.execute("SELECT COUNT(*) FROM architecture_decisions").fetchone()[0]
print(f"\n  DB: {r} robots | {j} joints | {ln} lenses | {ad} ADRs")

db.close()
PYEOF

ok "fleet.db seeded"
echo "  Section 02 done"
