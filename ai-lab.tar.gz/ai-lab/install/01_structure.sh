#!/usr/bin/env bash
# 01_structure.sh — Create project directories, .env, CLAUDE.md
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

ok()   { echo "  ✅  $1"; }
warn() { echo "  ⚠️   $1"; }

# ── Directories ───────────────────────────────────────────────────────────────
dirs=(
  db/seed
  agents/research agents/urdf agents/usd
  agents/physics agents/hitl agents/code
  shared/decisions shared/artifacts shared/logs
  cad/stl .rules
)
for d in "${dirs[@]}"; do
  mkdir -p "$ROOT/$d" && ok "$d"
done

# ── .env ─────────────────────────────────────────────────────────────────────
ENV="$ROOT/.env"
if [[ ! -f "$ENV" ]]; then
  cat > "$ENV" << 'EOF'
# ~/ai-lab — environment variables
# Fill in values. Never commit this file.

ANTHROPIC_API_KEY=sk-ant-...
FLEET_DB_PATH=./db/fleet.db

# Flair
FLAIR_HOST=192.168.1.100
FLAIR_PORT=5000

# Isaac Sim (Docker)
ISAAC_SIM_IMAGE=nvcr.io/nvidia/isaac-sim:4.5.0
ROS_DISTRO=humble

# Safety
LIVE_SYNC_ENABLED=false
EOF
  ok ".env created"
else
  warn ".env exists — not overwritten"
fi

# ── .gitignore ────────────────────────────────────────────────────────────────
GI="$ROOT/.gitignore"
[[ -f "$GI" ]] || cat > "$GI" << 'EOF'
.env
db/fleet.db-wal
db/fleet.db-shm
__pycache__/
*.pyc
shared/logs/*.jsonl
shared/artifacts/
.install_stamps/
EOF
ok ".gitignore"

# ── CLAUDE.md ─────────────────────────────────────────────────────────────────
CM="$ROOT/CLAUDE.md"
[[ -f "$CM" ]] || cat > "$CM" << 'EOF'
# CLAUDE.md — ai-lab session protocol

## Every session starts with:
```
cd ~/ai-lab
python agents/validate_session.py    # must pass
python agents/orchestrator.py --status
```

## Rules (non-negotiable)
1. All physics data goes through db/schema.py — never raw sqlite3
2. No URDF built from unverified (verified=0) data
3. No live sync without GATE-SAFE in gate_approvals table
4. Every physics record needs source_url or source_doc
5. R10 Bolt Jr blocked until nameplate read in person

## Running the pipeline
```
python agents/orchestrator.py --task pipeline --robot R02
python agents/orchestrator.py --approve GATE-DH --robot R02 --notes "verified"
```
EOF
ok "CLAUDE.md"

echo "  Section 01 done"
