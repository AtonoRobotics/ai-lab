#!/usr/bin/env bash
# 04_rules.sh — Install governance files, bootstrap architecture hash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

ok()   { echo "  ✅  $1"; }
warn() { echo "  ⚠️   $1"; }
fail() { echo "  ❌  $1"; exit 1; }

# ── Check governance files exist ──────────────────────────────────────────────
[[ -f "$ROOT/ARCHITECTURE.md" ]]        || fail "ARCHITECTURE.md not found"
[[ -f "$ROOT/.rules/IMMUTABLE.md" ]]    || fail ".rules/IMMUTABLE.md not found"
[[ -f "$ROOT/agents/validate_session.py" ]] || fail "agents/validate_session.py not found"

ok "ARCHITECTURE.md"
ok ".rules/IMMUTABLE.md"
ok "agents/validate_session.py"

# ── Bootstrap architecture hash ───────────────────────────────────────────────
cd "$ROOT"
HASH=$(python3 -c "
import hashlib
with open('ARCHITECTURE.md','rb') as f:
    print(hashlib.sha256(f.read()).hexdigest())
")
echo "  Architecture hash: ${HASH:0:16}..."

# Write hash into validate_session.py
python3 - "$HASH" << 'PYEOF'
import sys, re
from pathlib import Path

new_hash = sys.argv[1]
path = Path("agents/validate_session.py")
src = path.read_text()

updated = re.sub(
    r'ARCHITECTURE_HASH\s*=\s*"[^"]*"',
    f'ARCHITECTURE_HASH = "{new_hash}"',
    src
)

if updated == src:
    print("  ⚠️   Could not find ARCHITECTURE_HASH in validate_session.py")
    sys.exit(1)

path.write_text(updated)
print(f"  ✅  ARCHITECTURE_HASH updated in validate_session.py")
PYEOF

# ── Run validate_session ──────────────────────────────────────────────────────
echo ""
echo "  Running validate_session.py..."
python3 agents/validate_session.py && ok "validate_session passed" || {
  warn "validate_session reported issues — review output above"
}

echo "  Section 04 done"
echo ""
echo "  ── Next steps ─────────────────────────────────────────"
echo "  1. Fill in ~/ai-lab/.env (ANTHROPIC_API_KEY, FLAIR_HOST)"
echo "  2. cd ~/ai-lab"
echo "  3. python agents/orchestrator.py --status"
echo "  4. python agents/orchestrator.py --task pipeline --robot R02"
